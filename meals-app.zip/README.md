# meals-app

Hello guys, I have made a react-native meals app. I have shown that we can manage state by either using redux or context, I have also used navigation for traversing between screens and also added a drawer which can be opened on a specific screen, and many more. This app can be used on any platform, android or IOS. It is compatible on both.
